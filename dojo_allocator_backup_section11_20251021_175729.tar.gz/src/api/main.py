"""
FastAPI application entry point.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.api.routes import signals, positions, orders, health

app = FastAPI(
    title="Dojo Allocator API",
    description="Autonomous trading system API",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, tags=["Health"])
app.include_router(signals.router, prefix="/signals", tags=["Signals"])
app.include_router(positions.router, prefix="/positions", tags=["Positions"])
app.include_router(orders.router, prefix="/orders", tags=["Orders"])

@app.get("/")
def root():
    """Root endpoint."""
    return {
        "name": "Dojo Allocator API",
        "version": "1.0.0",
        "docs": "/docs"
    }
