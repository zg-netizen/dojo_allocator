"""Data ingestion package."""
