"""Core business logic package."""
